# Question

1. There is two files, one in csv file format the other one in json file format.
    - in csv file there is only a column named city_name
    - in json file  there is only a field named food_name
2. Ask chat gpt to get the country name from
    - where the city is located in. 
    - where the is food_named known for.
    * Try using requests at least one time instead of using openai sdk.
3. output two result. Name new column/field as you wish.
    - at least one with json format.
4. Get the same country in both file.  Combine information(country, city, food) from both file and then output. Just like table join.
5. Back to the csv file. Now filter out city name that is longer than 5 letters.
6. For the Combined data, print each row in following format? 
    - <food> is known for originate from <country> and one of its city is <city>.
7. Redo question 5, but if you answer with for and if statement then use map/filter this time. If you answer with map/filter, use for and if statement  this time.
8. Use argparse to make the script accepting arguments


---

## Note

1. read csv file, read json file
2. filter map
3. formatted string and string concatenation
4. openai api, request get and post
5. for if statement
6. argparse argv


